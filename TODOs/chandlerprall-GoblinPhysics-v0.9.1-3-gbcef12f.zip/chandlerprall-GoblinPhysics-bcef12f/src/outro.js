	if ( typeof window !== 'undefined' ) window.Goblin = Goblin;
	if ( typeof self !== 'undefined' ) self.Goblin = Goblin;
	if ( typeof module !== 'undefined' ) module.exports = Goblin;
})();