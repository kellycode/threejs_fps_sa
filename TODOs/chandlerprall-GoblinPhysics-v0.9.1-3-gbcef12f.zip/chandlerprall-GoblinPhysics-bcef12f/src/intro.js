/**
* Goblin Physics
*
* @module Goblin
*/
(function(){
	var Goblin = {};