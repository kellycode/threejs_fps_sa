Goblin.RayIntersection = function() {
	this.object = null;
	this.point = new Goblin.Vector3();
	this.t = null;
    this.normal = new Goblin.Vector3();
};